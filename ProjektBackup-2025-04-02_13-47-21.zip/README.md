„Dieses Projekt ist eine React + Blazor WebAssembly Hybrid-App als gemeischaftliche kostenplanung / verwaltung.“
