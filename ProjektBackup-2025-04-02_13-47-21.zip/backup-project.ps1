# backup-project.ps1
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$zipPath = "ProjektBackup-$timestamp.zip"

# Nur Git-getrackte Dateien auflisten
$files = git ls-files

# Temporärer Ordner für ZIP-Zwischenablage
$tempDir = "backup-temp"
Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $tempDir | Out-Null

# Dateien dorthin kopieren
foreach ($file in $files) {
    $target = Join-Path $tempDir $file
    $targetDir = Split-Path $target
    if (!(Test-Path $targetDir)) {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    }
    Copy-Item -Path $file -Destination $target
}

# ZIP erstellen
Compress-Archive -Path $tempDir\* -DestinationPath $zipPath -Force

# Aufräumen
Remove-Item -Recurse -Force $tempDir

Write-Host "Projekt wurde gespeichert als $zipPath (nur Git-Dateien)."
